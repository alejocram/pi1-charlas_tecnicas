var express = require('express');
var router = express.Router();
var text;
var title;
/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: title, text: text });
});

router.post('/', function(req,res) {
    text = req.body.text;
    title = req.body.title
    res.setHeader('Content-Type', 'application/json');
    res.send(JSON.stringify({ "success": true, "response": { "text": text, "title": title, } }));
})

module.exports = router;
